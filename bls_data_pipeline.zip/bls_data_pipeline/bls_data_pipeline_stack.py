from aws_cdk import (
    Stack, Duration,
    aws_lambda as _lambda,
    aws_events as events,
    aws_events_targets as targets,
    aws_s3 as s3,
    aws_sqs as sqs,
    aws_lambda_event_sources as lambda_event_sources,
    aws_s3_notifications as s3n
)
from constructs import Construct

class BlsDataPipelineStack(Stack):

    def __init__(self, scope: Construct, id: str, **kwargs):
        super().__init__(scope, id, **kwargs)

        bucket = s3.Bucket(self, "DataPipelineBucket")

        queue = sqs.Queue(self, "ReportQueue")

        sync_lambda = _lambda.Function(
            self, "SyncApiLambda",
            runtime=_lambda.Runtime.PYTHON_3_10,
            handler="sync_api_lambda.handler",
            code=_lambda.Code.from_asset("bls_data_pipeline/lambda"),
            environment={"BUCKET_NAME": bucket.bucket_name}
        )

        bucket.grant_write(sync_lambda)

        rule = events.Rule(
            self, "DailySchedule",
            schedule=events.Schedule.rate(Duration.days(1))
        )
        rule.add_target(targets.LambdaFunction(sync_lambda))

        bucket.add_event_notification(
            s3.EventType.OBJECT_CREATED,
            s3n.SqsDestination(queue),
            s3.NotificationKeyFilter(suffix="population_data.json")
        )

        report_lambda = _lambda.Function(
            self, "ReportLambda",
            runtime=_lambda.Runtime.PYTHON_3_10,
            handler="report_lambda.handler",
            code=_lambda.Code.from_asset("bls_data_pipeline/lambda"),
            environment={"BUCKET_NAME": bucket.bucket_name}
        )

        bucket.grant_read(report_lambda)
        queue.grant_consume_messages(report_lambda)

        report_lambda.add_event_source(
            lambda_event_sources.SqsEventSource(queue)
        )