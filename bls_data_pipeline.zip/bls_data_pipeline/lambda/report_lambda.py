import boto3
import os
import pandas as pd
import json

s3 = boto3.client("s3")
BUCKET = os.environ["BUCKET_NAME"]

def handler(event, context):
    pop_obj = s3.get_object(Bucket=BUCKET, Key="population_data.json")
    csv_obj = s3.get_object(Bucket=BUCKET, Key="pr.data.0.Current")

    population_data = json.loads(pop_obj["Body"].read())
    csv_data = pd.read_csv(csv_obj["Body"])

    csv_data.columns = csv_data.columns.str.strip()
    csv_data["value"] = pd.to_numeric(csv_data["value"], errors="coerce")

    pop_df = pd.DataFrame([
        {"year": int(item["date"]), "Population": int(item["value"].replace(",", ""))}
        for item in population_data["data"]
    ])

    filtered_pop = pop_df[(pop_df["year"] >= 2013) & (pop_df["year"] <= 2018)]
    mean_pop = filtered_pop["Population"].mean()
    std_pop = filtered_pop["Population"].std()
    print(f"Mean Population (2013-2018): {mean_pop}")
    print(f"Std Dev Population (2013-2018): {std_pop}")

    grouped = csv_data.groupby(["series_id", "year"])["value"].sum().reset_index()
    best_year = grouped.loc[grouped.groupby("series_id")["value"].idxmax()]
    print("Best Year Per Series ID:")
    print(best_year)

    filtered = csv_data[
        (csv_data["series_id"] == "PRS30006032") &
        (csv_data["period"] == "Q01")
    ]
    merged = pd.merge(filtered, pop_df, how="left", on="year")
    result = merged[["series_id", "year", "period", "value", "Population"]]
    print("Joined Report:")
    print(result)