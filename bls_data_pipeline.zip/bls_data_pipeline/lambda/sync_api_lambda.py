import boto3
import requests
import os

s3 = boto3.client("s3")
BUCKET = os.environ["BUCKET_NAME"]

def handler(event, context):
    # Download population JSON
    population_response = requests.get("https://api.datausa.io/api/data?drilldowns=Nation&measures=Population")
    population_data = population_response.json()
    s3.put_object(
        Bucket=BUCKET,
        Key="population_data.json",
        Body=str(population_data),
        ContentType="application/json"
    )

    # Download time-series CSV
    csv_url = "https://download.bls.gov/pub/time.series/pr/pr.data.0.Current"
    csv_data = requests.get(csv_url).text
    s3.put_object(
        Bucket=BUCKET,
        Key="pr.data.0.Current",
        Body=csv_data,
        ContentType="text/csv"
    )

    print("Files saved to S3.")