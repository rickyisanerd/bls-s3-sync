#!/usr/bin/env python3
import aws_cdk as cdk
from bls_data_pipeline.bls_data_pipeline_stack import BlsDataPipelineStack

app = cdk.App()
BlsDataPipelineStack(app, "BlsDataPipelineStack")
app.synth()